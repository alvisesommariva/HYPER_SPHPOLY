
function demo_sphpoly

%--------------------------------------------------------------------------
% Object:
% Demo on algebraic polynomial hyperinterpolation on spherical polygon.
% The determination of the X pointset varies with the choice of the
% parameter "pts_type".
%
% This code is based on the results of:
%
% A. Sommariva and M. Vianello
% Numerical hyperinterpolation over spherical triangles
%
% For degrees higher than 10 it may be a little time consuming. See "cpus"
% in the table below (Example section), for additional details.
%--------------------------------------------------------------------------
% Required routines:
% 1. define_domain (attached)
% 2. define_function (attached)
% 3. cub_sphpgon (external,requires other subroutines)
% 4. dPOLYFITsph (external, requires "dORTHVANDsph")
% 5. dPOLYVALsph (external, requires "dCHEBVAND")
% 6. dLEBsph (external, requires "dCHEBVAND", "dORTHVANDsph")
% 7. plot_s2 (external)
%--------------------------------------------------------------------------
% Example:
% % EXAMPLE SETTINGS: domain_example=2; function_typeV=1:6; nV=1:10;
% %                   pts_type=2;
% demo_hyp_sphpgon
%
%  	  1  2  3  4  5  6  7  8  9 10
%  	 .........................................................................
%  	 ** Domain:  2
%  	 ** Hyperinterpolation on compressed pointset
%
%  	 .........................................................................
%  	 |  n  |  hypset  |  initset  |  dimpoly |  cpus   |    leb   |
%  	 .........................................................................
%  	 |   1 |       9  |   25965   |     4    | 4.6e-02 | 2.97e+00 |
%  	 |   2 |      25  |   37071   |     9    | 1.2e-01 | 7.68e+00 |
%  	 |   3 |      49  |   50181   |    16    | 1.6e-01 | 1.12e+01 |
%  	 |   4 |      81  |   65295   |    25    | 4.4e-01 | 1.78e+01 |
%  	 |   5 |     121  |   82413   |    36    | 9.2e-01 | 2.02e+01 |
%  	 |   6 |     169  |   101535   |    49    | 2.2e+00 | 2.52e+01 |
%  	 |   7 |     225  |   122661   |    64    | 3.1e+00 | 2.97e+01 |
%  	 |   8 |     289  |   145791   |    81    | 4.8e+00 | 3.96e+01 |
%  	 |   9 |     361  |   170925   |   100    | 7.6e+00 | 4.22e+01 |
%  	 |  10 |     441  |   198063   |   121    | 1.5e+01 | 5.34e+01 |
%  	 .........................................................................
%
%
%  	 .........................................................................
%  	 For each function "f" and each degree we display the L2 relative weighted
%  	 hyperinterp. errors REL, evaluated w.r.t. to a high order cubature.
%  	 Next we compute RELinf, i.e. "maximum absolute error / norm(f,inf)".
%  	 .........................................................................
%
%
%  	 *** 1+x+y^2+x^2*y+x^4+y^5+x^2*y^2*z^2
%
%  	 .....................................
%  	 |  deg  |   REL2   |  RELinf  |
%  	 .....................................
%  	 |    1  | 1.72e-02 | 4.30e-02 |
%  	 |    2  | 2.88e-03 | 1.24e-02 |
%  	 |    3  | 7.86e-05 | 3.24e-04 |
%  	 |    4  | 3.54e-06 | 1.95e-05 |
%  	 |    5  | 2.94e-07 | 2.41e-06 |
%  	 |    6  | 5.93e-16 | 6.31e-15 |
%  	 |    7  | 6.77e-16 | 3.79e-15 |
%  	 |    8  | 6.87e-16 | 4.02e-15 |
%  	 |    9  | 6.69e-16 | 2.76e-15 |
%  	 |   10  | 6.74e-16 | 4.19e-15 |
%  	 .....................................
%
%
%  	 *** cos(10*(x+y+z))
%
%  	 .....................................
%  	 |  deg  |   REL2   |  RELinf  |
%  	 .....................................
%  	 |    1  | 1.16e+00 | 2.62e+00 |
%  	 |    2  | 5.91e-01 | 1.30e+00 |
%  	 |    3  | 2.58e-01 | 1.22e+00 |
%  	 |    4  | 8.78e-02 | 3.90e-01 |
%  	 |    5  | 2.96e-02 | 1.88e-01 |
%  	 |    6  | 8.08e-03 | 7.46e-02 |
%  	 |    7  | 1.57e-03 | 2.42e-02 |
%  	 |    8  | 3.47e-04 | 6.23e-03 |
%  	 |    9  | 5.33e-05 | 5.41e-04 |
%  	 |   10  | 9.91e-06 | 9.33e-05 |
%  	 .....................................
%
%
%  	 *** sin(-g(x,y,z)), g=@(x,y,z) (x-x0)^2+(y-y0)^2+(z-z0)^2, (x0,y0,z0)=(-6.325e-01,6.688e-01,-3.908e-01)
%
%  	 .....................................
%  	 |  deg  |   REL2   |  RELinf  |
%  	 .....................................
%  	 |    1  | 5.78e-04 | 1.69e-03 |
%  	 |    2  | 8.93e-05 | 3.10e-04 |
%  	 |    3  | 3.32e-08 | 2.44e-07 |
%  	 |    4  | 3.62e-09 | 3.15e-08 |
%  	 |    5  | 1.06e-12 | 1.46e-11 |
%  	 |    6  | 8.24e-14 | 1.44e-12 |
%  	 |    7  | 9.26e-16 | 3.02e-15 |
%  	 |    8  | 8.86e-16 | 3.81e-15 |
%  	 |    9  | 8.05e-16 | 2.86e-15 |
%  	 |   10  | 8.56e-16 | 4.15e-15 |
%  	 .....................................
%
%
%  	 *** exp(-g(x,y,z)), g=@(x,y,z) (x-x0)^2+(y-y0)^2+(z-z0)^2, (x0,y0,z0)=(-6.325e-01,6.688e-01,-3.908e-01)
%
%  	 .....................................
%  	 |  deg  |   REL2   |  RELinf  |
%  	 .....................................
%  	 |    1  | 5.73e-04 | 3.13e-03 |
%  	 |    2  | 4.24e-06 | 3.60e-05 |
%  	 |    3  | 2.86e-08 | 4.33e-07 |
%  	 |    4  | 1.71e-10 | 3.67e-09 |
%  	 |    5  | 8.79e-13 | 2.73e-11 |
%  	 |    6  | 3.92e-15 | 1.69e-13 |
%  	 |    7  | 4.89e-16 | 2.78e-15 |
%  	 |    8  | 5.18e-16 | 6.11e-15 |
%  	 |    9  | 5.07e-16 | 4.89e-15 |
%  	 |   10  | 5.43e-16 | 5.55e-15 |
%  	 .....................................
%
%
%  	 *** ((x-x0)^2 + (y-y0)^2 + (z-z0)^2).^(3/2), (x0,y0,z0)=(-6.325e-01,6.688e-01,-3.908e-01)
%
%  	 .....................................
%  	 |  deg  |   REL2   |  RELinf  |
%  	 .....................................
%  	 |    1  | 1.75e-01 | 2.52e-01 |
%  	 |    2  | 1.58e-02 | 2.91e-02 |
%  	 |    3  | 4.03e-03 | 9.96e-03 |
%  	 |    4  | 1.62e-03 | 5.55e-03 |
%  	 |    5  | 8.01e-04 | 3.52e-03 |
%  	 |    6  | 4.38e-04 | 2.59e-03 |
%  	 |    7  | 2.57e-04 | 1.35e-03 |
%  	 |    8  | 1.64e-04 | 9.62e-04 |
%  	 |    9  | 1.07e-04 | 9.13e-04 |
%  	 |   10  | 7.44e-05 | 5.72e-04 |
%  	 .....................................
%
%
%  	 *** ((x-x0)^2 + (y-y0)^2 + (z-z0).^2)^(5/2),, (x0,y0,z0)=(-6.325e-01,6.688e-01,-3.908e-01)
%
%  	 .....................................
%  	 |  deg  |   REL2   |  RELinf  |
%  	 .....................................
%  	 |    1  | 4.21e-01 | 5.62e-01 |
%  	 |    2  | 3.46e-02 | 5.50e-02 |
%  	 |    3  | 2.61e-03 | 5.96e-03 |
%  	 |    4  | 5.55e-04 | 1.65e-03 |
%  	 |    5  | 1.74e-04 | 6.82e-04 |
%  	 |    6  | 6.70e-05 | 3.43e-04 |
%  	 |    7  | 2.93e-05 | 1.32e-04 |
%  	 |    8  | 1.45e-05 | 7.11e-05 |
%  	 |    9  | 7.63e-06 | 5.47e-05 |
%  	 |   10  | 4.34e-06 | 2.83e-05 |
%  	 .....................................
%
% >>
% .........................................................................
% Reference paper:
% A. Sommariva and M. Vianello
% Numerical hyperinterpolation over spherical triangles
%--------------------------------------------------------------------------
% Information:
% Authors: A. Sommariva, M. Vianello.
% Date: June 13, 2021.
%--------------------------------------------------------------------------
%% Copyright (C) 2021
%% Alvise Sommariva, Marco Vianello.
%%
%% This program is free software; you can redistribute it and/or modify
%% it under the terms of the GNU General Public License as published by
%% the Free Software Foundation; either version 2 of the License, or
%% (at your option) any later version.
%%
%% This program is distributed in the hope that it will be useful,
%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%% GNU General Public License for more details.
%%
%% You should have received a copy of the GNU General Public License
%% along with this program; if not, write to the Free Software
%% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%%
%% Authors:
%% Alvise Sommariva, Marco Vianello.
%%
%% Date: JULY 13, 2021
%--------------------------------------------------------------------------




clear; clf;

%--------------------------------------------------------------------------
% domain_example: determines the spherical polygon to be analysed.
%                 0: Polygonal cap at North-Pole.
%                 1: Cardioid at North-Pole.
%                 2. Coarse Australia (no Tasmania, from "vector" data).
%                 3. Coarse Australia (no Tasmania, from "polyshape" data).
%--------------------------------------------------------------------------

domain_example=3;

%--------------------------------------------------------------------------
% Function to study. The variable "function_typeV" can be:
%
% case 1, f=@(x,y,z) 1+x+y.^2+x.^2.*y+x.^4+y.^5+x.^2.*y.^2.*z.^2;
% case 2, f=@(x,y,z) cos(10*(x+y+z));
% case 3  x0=0; y0=0; z0=1;
%         g=@(x,y,z) (x-x0).^2 + (y-y0).^2 + (z-z0).^2;
%         f=@(x,y,z) exp( - g(x,y,z) );
% case 4  centroid=sum(vertices,1); centroid=centroid/norm(centroid);
%         x0=centroid(1); y0=centroid(2); z0=centroid(3);
%         g=@(x,y,z) (x-x0).^2 + (y-y0).^2 + (z-z0).^2;
%         f=@(x,y,z) exp( - g(x,y,z) );
% case 5  centroid=sum(vertices,1); centroid=centroid/norm(centroid);
%         x0=centroid(1); y0=centroid(2); z0=centroid(3);
%         f=@(x,y,z) ((x-x0).^2 + (y-y0).^2 + (z-z0).^2).^(5/2);
% case 6  centroid=sum(vertices,1); centroid=centroid/norm(centroid);
%         x0=centroid(1); y0=centroid(2); z0=centroid(3);
%         f=@(x,y,z) ((x-x0).^2 + (y-y0).^2 + (z-z0).^2).^(5/2);
%
% Note that the variable "function_typeV" is a vector and several
% experiments will be performed. The error of each experiment will be
% described in a final figure with all the errors will be made.
%--------------------------------------------------------------------------

function_typeV=1:6;

%--------------------------------------------------------------------------
% Degrees in numerical experiments: can be a vector.
% Use mild degrees, typically not beyond 10.
%--------------------------------------------------------------------------

nV=1:5;

%--------------------------------------------------------------------------
% Approximation type parameter "pts_type".
%     case 1, pts_type='Hyperinterpolation full set';
%     case 2, pts_type='Hyperinterpolation compressed set';
%
% Note: the case "2" should be used for mild values of "n", say at most 15.
%--------------------------------------------------------------------------
pts_type=2;

%--------------------------------------------------------------------------
% Plot domain and nodes: do_plot=1 (yes), do_plot=0 (no).
%--------------------------------------------------------------------------
do_plot=1;







% ........................ Main code below ................................

% ....... Apply settings to define domain, pointsets, and functions .......

% Domain
[vertices,domain_str]=define_domain(domain_example);
P1=vertices(1,:); P2=vertices(2,:); P3=vertices(3,:);
[XYZWR,tri_vertices,tri_conn_list]=cub_sphpgon(10,vertices);
XR=XYZWR(:,1:3); wr=XYZWR(:,4);



% ........ Numerical approximation, varying the degree in "nV" ............

fprintf('\n \t ');
for k=1:length(nV)
    n=nV(k);
    fprintf('%2.0f ',n);
    
    tic;
    
    % ... extract hyperinterpolation set (notice that ade=2*n) ...
    if pts_type == 2 % compressed set
        XYZW=cub_sphpgon(2*n,vertices);
        [pts,weights,momerr,dbox] = dCATCHsph(2*n,XYZW(:,1:3),XYZW(:,4));
        XYZWC=[pts weights];
        X=XYZW(:,1:3); w=XYZW(:,4);
    else % full set
        XYZW=cub_sphpgon(2*n,vertices);
        X=XYZW(:,1:3); w=XYZW(:,4);
        pts=XYZW(:,1:3); weights=XYZW(:,4);
    end
    cpus(k)=toc;
    
    
    
    % .. testing AE_L2err hyperinterpolation error for each "f" at "deg" ..
    
    for j=1:length(function_typeV)
        
        function_type=function_typeV(j);
        
        % Function to approximate
        [g,gs]=define_function(function_type,vertices);
        
        % ... evaluate function to approximate ...
        g_pts=feval(g,pts(:,1),pts(:,2),pts(:,3));
        
        % ... determine polynomial hyperinterpolant ...
        [coeff,R,jvec,dbox] = dPOLYFITsph(n,pts,weights,g_pts,[],[]);
        
        % ... evaluate hyperinterpolant at initial pointset ...
        p_X=dPOLYVALsph(n,coeff,XR,R,jvec,dbox);
        
        % ... estimating hyperinterpolant error ...
        g_X=feval(g,XR(:,1),XR(:,2),XR(:,3));
        
        AE_L2err(k,j)=sqrt(wr'*(p_X-g_X).^2);
        
        % ... estimating filtered relative error in infinity norm ...
        % tol=10^(-12); iok=find(g_X >= tol & g_X <= 1/tol);
        AE_inf(k,j)=norm(p_X-g_X,inf);
        RE_inf(k,j)=AE_inf(k,j)/norm(g_X,inf);
        
    end
    
    
    
    % ... Lebesgue constant estimate ...
    leb(k) = dLEBsph(n,pts,weights,X,jvec,dbox);
    
    
    
    % ... Parameters for statistics ...
    card_X(k)=size(X,1);  card_pts(k)=size(pts,1);
    card_polyspace(k)=length(jvec); card_sphharm(k)=(n+1)^2;
    
end







% ............................... Plots ...................................

if do_plot == 1
    
    % ....... figure 1 (domain) .......
    
    clf;
    figure(1);
    R=norm(vertices(1,:));
    title_str=strcat(domain_str,': hyperinterpolation pointset.');
    title(title_str);
    hold on;
    plot_s2('spherical-polygon',vertices,[],pts,title_str,R,...
        tri_vertices,tri_conn_list);
    hold off;
    
    
    
    
    % ....... figure 2 (L2 hyp. error) .......
    
    figure(2);
    all_marks = {'o','v','*','d','x','s','.','^','+','>','<','p','h'};
    
    for j=1:length(function_typeV)
        
        % ... approximating L2 norm of function "g" ...
        function_type=function_typeV(j);
        [g,gs]=define_function(function_type,vertices);
        g_X=feval(g,XR(:,1),XR(:,2),XR(:,3));
        g_L2=sqrt(wr'*(g_X).^2);
        
        % ... computing L2 hyperinterpolation relative error ...
        RE_L2err(:,j)=AE_L2err(:,j)/g_L2;
        
        % ... plotting error ...
        
        marker_type=all_marks{j};
        semilogy(nV,RE_L2err(:,j),'LineWidth',1.5,'Marker',marker_type);
        hold on;
        
    end
    L=length(function_typeV);
    if L == 6, legend('f1','f2','f3','f4','f5','f6'); end
    
    title_str=strcat(domain_str,': L2 hyp. error of several functions.');
    title(title_str);
    hold off;
    
    
    
    
    % ....... figure 3 (hyp. error inf norm) .......
    
    figure(3);
    all_marks = {'o','v','*','d','x','s','.','^','+','>','<','p','h'};
    
    for j=1:length(function_typeV)
        
        % ... plotting error ...
        
        marker_type=all_marks{j};
        semilogy(nV,RE_inf(:,j),'LineWidth',1.5,'Marker',marker_type);
        hold on;
        
    end
    L=length(function_typeV);
    if L == 6, legend('f1','f2','f3','f4','f5','f6'); end
    
    title_str=strcat(domain_str,': Inf Norm hyp. error of several functions.');
    title(title_str);
    
    hold off;
    
end





% ............................ General Statistics .........................


fprintf('\n \t .........................................................................');
fprintf('\n \t ** Domain: %2.0f',domain_example)
if pts_type == 1
    fprintf('\n \t ** Hyperinterpolation on full pointset \n \t');
else
    fprintf('\n \t ** Hyperinterpolation on compressed pointset \n \t');
end

fprintf('\n \t .........................................................................');
fprintf('\n \t |  n  |  hypset  |  initset  |  dimpoly |  cpus   |    leb   |');
fprintf('\n \t .........................................................................');
for k=1:length(nV)
    fprintf('\n \t | %3.0f |   %5.0f  |   %5.0f   | %5.0f    | %1.1e | %1.2e |',...
        nV(k),card_pts(k),card_X(k),card_polyspace(k),cpus(k),leb(k));
end
fprintf('\n \t .........................................................................');
fprintf('\n \n');




% ............................ L2 Error Statistics ........................

fprintf('\n \t .........................................................................');
fprintf('\n \t For each function "f" and each degree we display the L2 relative weighted');
fprintf('\n \t hyperinterp. errors REL, evaluated w.r.t. to a high order cubature.');
fprintf('\n \t Next we compute RELinf, i.e. "maximum absolute error / norm(f,inf)".');
fprintf('\n \t .........................................................................');
for j=1:length(function_typeV)
    function_type=function_typeV(j);
    [g,gs]=define_function(function_type,vertices);
    fprintf('\n \n \n \t *** ');disp(gs);
    fprintf('\n \t .....................................');
    fprintf('\n \t |  deg  |   REL2   |  RELinf  |');
    fprintf('\n \t .....................................');
    for k=1:length(nV)
        n=nV(k);
        fprintf('\n \t |  %3.0f  | %1.2e | %1.2e |',n,RE_L2err(k,j),...
            RE_inf(k,j));
    end
    fprintf('\n \t .....................................');
end

fprintf('\n \n');











function [f,fs]=define_function(function_type,parms)

%--------------------------------------------------------------------------
% Object:
% This routine, defines a function "f" to approximate and a string "fs" for
% possible messages to the user.
%--------------------------------------------------------------------------
% Input:
% function_type: determines the function to study.
% The first five functions has been used in the paper mentioned below.
%
% case 1, f=@(x,y,z) 1+x+y.^2+x.^2.*y+x.^4+y.^5+x.^2.*y.^2.*z.^2;
% case 2, f=@(x,y,z) cos(10*(x+y+z));
% case 3  x0=0; y0=0; z0=1;
%         g=@(x,y,z) (x-x0).^2 + (y-y0).^2 + (z-z0).^2;
%         f=@(x,y,z) exp( - g(x,y,z) );
% case 4  centroid=sum(vertices,1); centroid=centroid/norm(centroid);
%         x0=centroid(1); y0=centroid(2); z0=centroid(3);
%         g=@(x,y,z) (x-x0).^2 + (y-y0).^2 + (z-z0).^2;
%         f=@(x,y,z) exp( - g(x,y,z) );
% case 5  x0=0; y0=0; z0=1;
%         f=@(x,y,z) ((x-x0).^2 + (y-y0).^2 + (z-z0).^2).^(5/2);
% case 6  centroid=sum(vertices,1); centroid=centroid/norm(centroid);
%         x0=centroid(1); y0=centroid(2); z0=centroid(3);
%         f=@(x,y,z) ((x-x0).^2 + (y-y0).^2 + (z-z0).^2).^(5/2);
% parms: parameters useful for defining the function definition, e.g.
%        the vertices, to determine the centroid (x0,y0,z0) and a function
%        based on the centroid (cartesian coordinates).
%--------------------------------------------------------------------------
% Output:
% f: defines a function "f" to approximate;
% fs: string with the content of the function "f".
%--------------------------------------------------------------------------
% Reference paper:
% A. Sommariva and M. Vianello
% Numerical hyperinterpolation overspherical triangles
%--------------------------------------------------------------------------

switch function_type
    case 1 % Fornberg
        f=@(x,y,z) 1+x+y.^2+x.^2.*y+x.^4+y.^5+x.^2.*y.^2.*z.^2;
        fs='1+x+y^2+x^2*y+x^4+y^5+x^2*y^2*z^2';
        
    case 2
        f=@(x,y,z) cos(10*(x+y+z));
        fs='cos(10*(x+y+z))';
        
    case 3 % exp and - square north pole distance
        if nargin < 1
            x0=0; y0=0; z0=1;
        else
            vertices=parms;
            ok_vertices=find( isnan(vertices(:,1))== 0 & isnan(vertices(:,2)) == 0 );
            vertices=vertices(ok_vertices,:);
            centroid=sum(vertices,1); centroid=centroid/norm(centroid);
            x0=centroid(1); y0=centroid(2); z0=centroid(3);
        end
        
        g=@(x,y,z) (x-x0).^2 + (y-y0).^2 + (z-z0).^2;
        f=@(x,y,z) sin( - g(x,y,z) );
        
        % ... output string ...
        x0str=num2str(x0,'%1.3e');
        y0str=num2str(y0,'%1.3e');
        z0str=num2str(z0,'%1.3e');
        fs='sin(-g(x,y,z)), g=@(x,y,z) (x-x0)^2+(y-y0)^2+(z-z0)^2';
        fs=strcat(fs,', (x0,y0,z0)=(',x0str,',',y0str,',',z0str,')');
        
    case 4 % exp and - square centroid distance
        if nargin < 1
            x0=0; y0=0; z0=1;
        else
            vertices=parms;
            ok_vertices=find( isnan(vertices(:,1))== 0 & isnan(vertices(:,2)) == 0 );
            vertices=vertices(ok_vertices,:);
            centroid=sum(vertices,1)/length(vertices);
            centroid=centroid/norm(centroid);
            x0=centroid(1); y0=centroid(2); z0=centroid(3);
        end
        
        % ... function ...
        g=@(x,y,z) (x-x0).^2 + (y-y0).^2 + (z-z0).^2;
        f=@(x,y,z) exp(-g(x,y,z) );
        
        
        % ... output string ...
        x0str=num2str(x0,'%1.3e');
        y0str=num2str(y0,'%1.3e');
        z0str=num2str(z0,'%1.3e');
        fs='exp(-g(x,y,z)), g=@(x,y,z) (x-x0)^2+(y-y0)^2+(z-z0)^2';
        fs=strcat(fs,', (x0,y0,z0)=(',x0str,',',y0str,',',z0str,')');
        
    case 5 % Centroid (or North-Pole) distance like
        if nargin < 1
            x0=0; y0=0; z0=1;
        else
            vertices=parms;
            ok_vertices=find( isnan(vertices(:,1))== 0 & isnan(vertices(:,2)) == 0 );
            vertices=vertices(ok_vertices,:);
            centroid=sum(vertices,1)/length(vertices);
            centroid=centroid/norm(centroid);
            x0=centroid(1); y0=centroid(2); z0=centroid(3);
        end
        
        
        f=@(x,y,z) ((x-x0).^2 + (y-y0).^2 + (z-z0).^2).^(3/2);
        
        % ... output string ...
        x0str=num2str(x0,'%1.3e');
        y0str=num2str(y0,'%1.3e');
        z0str=num2str(z0,'%1.3e');
        fs='((x-x0)^2 + (y-y0)^2 + (z-z0)^2).^(3/2)';
        fs=strcat(fs,', (x0,y0,z0)=(',x0str,',',y0str,',',z0str,')');
        
        
    case 6 % Centroid (or North-Pole) distance like
        if nargin < 1
            x0=0; y0=0; z0=1;
        else
            vertices=parms;
            ok_vertices=find( isnan(vertices(:,1))== 0 & isnan(vertices(:,2)) == 0 );
            vertices=vertices(ok_vertices,:);
            centroid=sum(vertices,1)/length(vertices);
            centroid=centroid/norm(centroid);
            x0=centroid(1); y0=centroid(2); z0=centroid(3);
        end
        
        % ... function ...
        f=@(x,y,z) ((x-x0).^2 + (y-y0).^2 + (z-z0).^2).^(5/2);
        
        % ... output string ....
        x0str=num2str(x0,'%1.3e');
        y0str=num2str(y0,'%1.3e');
        z0str=num2str(z0,'%1.3e');
        fs='((x-x0)^2 + (y-y0)^2 + (z-z0).^2)^(5/2), ';
        fs=strcat(fs,', (x0,y0,z0)=(',x0str,',',y0str,',',z0str,')');
        
end  % end: "define_function"









function [vertices,domain_str]=define_domain(example)

%--------------------------------------------------------------------------
% Object:
% This routine, defines the domain to analyse.
%--------------------------------------------------------------------------
% Input:
% example: determines the spherical triangle domain to be analysed. From 0
%   to 7, going from large domains to tiny ones (the higher "example", the
%   smaller the domain.
%--------------------------------------------------------------------------
% Output:
% vertices: it is a matrix whose rows are the vertices of the spherical
%           triangles.
% domain_str: string that stores the geometry of the region.
%--------------------------------------------------------------------------


switch example
    
    case 0
        % Define spherical polygon.
        factor=0.5;
        t=linspace(0,2*pi,10); t=(t(1:end-1))';
        XV=factor*cos(t); YV=factor*sin(t); ZV=sqrt(1-XV.^2-YV.^2);
        % Note: spherical polygon (first vertices not equal to last).
        vertices=[XV YV ZV];
        
        domain_str='Polygonal cap at North-Pole (9 vertices)';
        
    case 1
        
        spec_settings=32;
        th=linspace(0,2*pi,spec_settings+1);
        %th=(th(1:end-1))';
        polygon_sides=[cos(th').*(1-cos(th')) sin(th').*(1-cos(th'))];
        polygon_sides=polygon_sides(1:end-1,:);
        XV=polygon_sides(:,1); XV=XV/2.1;
        YV=polygon_sides(:,2); YV=YV/2.1;
        ZV=sqrt(1-XV.^2-YV.^2);
        vertices=[XV YV ZV];
        
        domain_str='Polygonal cardioid at North-Pole (32 vertices)';
        
    case 2
        
        % Australia island vertices in degrees.
        % Column 1: Longitude. Column 2: Latitude.
        vertices_degs=[
            146.230028000000004 -38.697082999999999
            146.276221999999990 -39.000000000000000
            145.371638999999988 -38.539611000000001
            145.488305999999994 -38.235444000000001
            144.658360999999985 -38.311278000000001
            145.116277999999994 -38.148333000000001
            144.928305999999992 -37.842917000000000
            143.556638999999990 -38.858750000000001
            140.581666999999982 -38.032916999999998
            139.740361000000007 -37.183306000000002
            139.612110999999999 -36.156721999999995
            139.722471999999982 -36.288806000000001
            139.517555999999985 -35.961250000000000
            138.890805999999998 -35.533749999999998
            138.097860999999995 -35.626694000000001
            138.567860999999994 -34.826667000000000
            138.094193999999987 -34.135416999999997
            137.762555999999989 -35.117944000000001
            136.851693999999981 -35.285416999999995
            137.015832999999986 -34.895443999999998
            137.452944000000002 -34.908332999999999
            137.450444000000005 -34.140028000000001
            137.977916999999991 -33.553360999999995
            137.754138999999981 -32.458777999999995
            137.781000000000006 -33.000000000000000
            135.933721999999989 -34.534193999999999
            135.957499999999982 -35.007916999999999
            135.112888999999996 -34.589999999999996
            135.518749999999983 -34.614193999999998
            134.707916999999981 -33.181666999999997
            134.059610999999990 -32.914138999999999
            134.181667000000004 -32.485416999999998
            131.152471999999989 -31.464582999999998
            125.957499999999996 -32.288778000000001
            124.234138999999999 -33.019582999999997
            123.526666999999989 -33.937971999999995
            119.903360999999990 -33.934582999999996
            117.953305999999998 -35.128777999999997
            116.624139000000000 -35.057943999999999
            115.128305999999995 -34.372943999999997
            115.000416999999999 -33.528360999999997
            115.697916999999990 -33.300860999999998
            115.882943999999995 -31.961693999999998
            115.052110999999996 -30.507527999999997
            114.867055999999991 -29.114193999999998
            113.152861000000001 -26.149193999999998
            113.837916999999990 -26.591666999999998
            113.509110999999990 -25.505416999999998
            113.722082999999998 -26.200028000000000
            113.870806000000002 -25.942083000000000
            114.231221999999988 -26.315888999999999
            113.396249999999995 -24.406693999999998
            113.990416999999994 -21.872527999999999
            114.330027999999999 -22.522138999999999
            114.645832999999996 -21.837916999999997
            116.804166999999993 -20.523778000000000
            117.377471999999997 -20.777082999999998
            119.092472000000001 -19.957916999999998
            121.113305999999994 -19.539611000000001
            122.369555999999989 -18.117500000000000
            122.172916999999998 -17.263332999999999
            122.922528000000000 -16.387944000000001
            123.566721999999999 -17.627082999999999
            123.569527999999991 -17.037555999999999
            123.930805999999990 -17.267917000000001
            123.971277999999998 -16.825832999999999
            123.504582999999997 -16.662499999999998
            123.557499999999990 -16.173749999999998
            124.400027999999992 -16.565443999999999
            124.976249999999993 -16.381722000000000
            124.391306000000000 -16.339221999999999
            124.750388999999998 -15.810889000000000
            124.494999999999990 -16.002972000000000
            124.360416999999998 -15.670027999999999
            124.675027999999998 -15.254582999999998
            125.249583000000001 -15.581666999999999
            124.829555999999997 -15.157471999999999
            125.506693999999996 -15.172056000000000
            125.137889000000001 -14.745832999999999
            125.614166999999995 -14.230471999999999
            125.918360999999990 -14.677083000000000
            126.009166999999991 -13.920389000000000
            126.230027999999990 -14.250416999999999
            126.535805999999994 -13.932082999999999
            126.612527999999998 -14.250416999999999
            126.874972000000000 -13.747138999999999
            127.428332999999995 -13.942943999999999
            128.227056000000005 -14.714193999999999
            128.009972000000005 -15.513750000000000
            128.128332999999998 -15.186249999999999
            128.372139000000004 -15.496694000000000
            128.199582999999990 -15.069222000000000
            128.559138999999988 -14.766278000000000
            129.092527999999987 -14.904610999999999
            129.125860999999986 -15.281277999999999
            129.289999999999992 -14.862083000000000
            129.605832999999990 -15.206249999999999
            129.998777999999987 -14.705860999999999
            129.365417000000008 -14.339971999999999
            129.816638999999981 -13.499582999999999
            130.317971999999997 -13.373332999999999
            130.351222000000007 -12.670028000000000
            130.732082999999989 -12.728332999999999
            130.575832999999989 -12.407110999999999
            130.964971999999989 -12.671277999999999
            130.812139000000002 -12.408332999999999
            131.287527999999980 -12.045444000000000
            131.462500000000006 -12.285444000000000
            132.762944000000005 -12.154582999999999
            132.722971999999999 -11.623332999999999
            131.767888999999997 -11.325832999999999
            131.973332999999997 -11.127110999999999
            133.508332999999993 -11.879583000000000
            133.915832999999992 -11.742082999999999
            134.150889000000006 -12.174583000000000
            134.748389000000003 -11.951250000000000
            135.215388999999988 -12.300860999999999
            135.912499999999994 -11.952916999999999
            135.652888999999988 -12.206666999999999
            136.044999999999987 -12.064610999999999
            136.016694000000001 -12.498778000000000
            136.564138999999983 -11.879610999999999
            136.977971999999994 -12.348333000000000
            136.462083000000007 -12.777500000000000
            136.461667000000006 -13.253777999999999
            135.909555999999981 -13.285000000000000
            136.072111000000007 -13.667527999999999
            135.411221999999981 -14.934972000000000
            136.676666999999981 -15.926305999999999
            139.036638999999980 -16.912917000000000
            139.598360999999983 -17.538778000000001
            140.609166999999985 -17.613806000000000
            141.667027999999988 -15.040861000000000
            141.461250000000007 -13.852528000000000
            141.976832999999999 -12.594778000000000
            141.586221999999992 -12.558361000000000
            142.079611000000000 -11.985861000000000
            142.130388999999980 -10.961694000000000
            142.534166999999997 -10.688722000000000
            143.545416999999986 -12.844166999999999
            143.772917000000007 -14.399194000000000
            144.515055999999987 -14.166250000000000
            145.347888999999981 -14.949193999999999
            145.402139000000005 -16.434999999999999
            145.957888999999994 -16.897527999999998
            146.260444000000007 -18.863388999999998
            148.772943999999995 -20.236694000000000
            149.630471999999997 -22.584999999999997
            149.812500000000000 -22.382110999999998
            150.060417000000001 -22.658360999999999
            150.041666999999990 -22.125416999999999
            150.635861000000006 -22.660443999999998
            150.668306000000001 -22.347082999999998
            150.791666999999990 -23.509611000000000
            151.769555999999994 -24.020861000000000
            153.192943999999983 -25.931694000000000
            153.024583000000007 -27.294193999999997
            153.639582999999988 -28.638361000000000
            153.065416999999997 -31.058388999999998
            152.359555999999998 -32.186667000000000
            152.542944000000006 -32.444221999999996
            151.201222000000001 -33.510832999999998
            150.602943999999979 -34.865832999999995
            150.842943999999989 -35.066693999999998
            150.152972000000005 -35.700972000000000
            149.979611000000006 -37.505055999999996
            147.657471999999984 -37.850443999999996
            147.454138999999998 -38.079611000000000
            147.972082999999998 -37.893360999999999
            146.230028000000004 -38.697082999999999
            ];
        
        % Australia island vertices in radians.
        longitudes=deg2rad(vertices_degs(:,1));
        latitudes=deg2rad(vertices_degs(:,2));
        
        % Australia island vertices in cartesian coordinates.
        [XX,YY,ZZ] = sph2cart(longitudes,latitudes,1);
        vertices=[XX YY ZZ];
        
        domain_str='Australia as island (170 vertices, via data)';
        
    case 3
        
        % Australia island (no Tasmania), vertices in degrees.
        % Column 1: Longitude. Column 2: Latitude.
        % Planar domain in polyshape form.
        australia_pshape=coastline_australia(0);
        vertices_degs=australia_pshape.Vertices;
        
        % Australia & Tasmania vertices in radians.
        longitudes=deg2rad(vertices_degs(:,1));
        latitudes=deg2rad(vertices_degs(:,2));
        
        % Australia & Tasmania vertices in cartesian coordinates.
        [XX,YY,ZZ] = sph2cart(longitudes,latitudes,1);
        vertices=[XX YY ZZ];
        
        domain_str='Australia as island (170 vertices, via polyshape)';
        
        
end

















