
function demo_sphpol_driver

%--------------------------------------------------------------------------
% OBJECT.
% This function runs the experiments for hyperinterpolation over a 
% spherical polygon.
%
% Several hyperinterpolants are use on possibly noisy functions.
%
% It makes the following numerical experiments:
% a) Fixed noise and several well-chosen lambda parameters (where useful).
% b) Fixed lambda and variable noise.
%
% At the end of the code
% 1. it produces the pertinent Latex files, making the relavant table.
% 2. it plots graphics comparing sparsity and L2 err. on some hyp.variants.
% 3. it plots J(z), H(z), as in Thm.5 of the accompanying paper. 
%--------------------------------------------------------------------------
% In the paper "Hybrid hyperinterpolation over general regions", we
% consider:
%
% 1. f(x,y,z)=linear combination of Wendland RBF.
% 2. Maximum hyperinterpolant degree: 15 (rule: ade=30).
% 3. Reference cubature rule degree of precision: 50.
% 4. Experiment 1. Noise: a=0.02, sigma=0.02, lambda index=[5 50 100 200].
% 5. Experiment 2. Noise: a=[0.015 0.02 0.025 0.03],sigma=0,lambda index=50.
% 6. Experiment 3. Average Lambda: 5.202e-03.
% 7. Cubature points for hyperinterpolation: 482.
% 8. Cubature points for testing L2 errors: 1302.
% 9. Total amount of hyperinterpolation coefficients: 256.
%
% a) This routine runs the experiments cited in the paper above.
% b) The process took 104 seconds on a MacBook Pro, with Apple M1 processor
% and 16 GB of RAM (Stage 3 may be time consuming).
% c) Rules taken from: "Efficient Spherical Designs with Good Geometric
%   Properties".
%--------------------------------------------------------------------------
% Dates:
% Written on September 29, 2023: A. Sommariva.
% Modified on September 29, 2023: A. Sommariva.
% Joint work with G. Elefante and M. Vianello.
%--------------------------------------------------------------------------
% Reference paper:
% "Hybrid hyperinterpolation over general regions" 
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023- 
%
% Authors:
% Alvise Sommariva
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------


clear;

% ............................. SETTINGS ..................................

% LV is the hyperinterpolation degree.
LV=5;

% a) PART 1: fixed noise
kV=ceil(linspace(1,(LV+1)^2,5));
a1=0.02; sigma1=0.02;

% b) PART 2: fixed lambda
kS=10; % lambda is choosen equal to the "k"-th hyp. coeff. in magnitude.
a2=0.02; sigma2V=[0.015 0.02 0.025 0.03]; % noise parameters

% c) PART 3: sparsity plots
kP=kV;
a3=0.02; sigma3=0.02;

% d) DOMAIN PARMS.
% 1. Polygonal cardioid at North-Pole, 
% 2. Australia coarse. 
% 3: Australia finer (no Tasmania).

domain_parm=1; 

do_compression=1;



% ........................ main code below ................................



% .................... FIRST STAGE OF EXPERIMENTS   .......................

fprintf(2,'\n \n \n \t * <strong>Stage 1.</strong> \n \n \n ') 

tic;

[vertices,domain_str]=define_domain(domain_parm);

AE2V=[]; betaV=[]; lambdaHIST=[];
XYZW=[]; XYZWR=[];

for k=kV

    % Technical note: Here we reuse the cub. rules once they are computes.
    [AEinf,AE2,beta,lambdaV,lambdaLV,XYZW,XYZWR]=demo_sphpoly(k,a1,sigma1,...
        vertices,XYZW,XYZWR,do_compression);
    AE2V=[AE2V AE2]; betaV=[betaV beta]; lambdaHIST=[lambdaHIST lambdaV];
   

end

AE2T=AE2V(1,:); BETAT=betaV(1,:); % tikhonov data storage
AE2F=AE2V(2,:); BETAF=betaV(2,:); % filtered hyp. data storage
AE2L=AE2V(3,:); BETAL=betaV(3,:); % lasso hyp. data storage
AE2H=AE2V(4,:); BETAH=betaV(4,:); % Hybrid hyp. data storage
AE2HA=AE2V(5,:); BETAHA=betaV(5,:); % Hard hyp. data storage
AE20=AE2V(6,:); BETA0=betaV(6,:); % Hyp. data storage


% Making Matlab tables
AE2V1=AE2V; betaV1=betaV; BETAH1=BETAH;

fprintf('\n \n')
HypType=categorical({'tikhonov'; 'filtered'; 'lasso'; 'hybrid'; 'hard'; ...
    'hyperint.'; 'hyb.spars.'});
tablemat=[AE2V1; BETAH1];
T = table(HypType,tablemat); disp(T);

fprintf('\n \t * Lambda interval (for hyp. variants): [%1.2e,%1.2e] \n',...
    min(min(lambdaHIST(kV,:))),max(max(lambdaHIST(kV,:))));

for k=1:length(kV)
    kVL=kV(k);
    fprintf('\n \t * Lambda %1.0f column (average): %1.4e AE2: %1.3e',...
    k,mean(lambdaHIST(kVL,:)),AE2V(4,k));
end



% ...................... SECOND STAGE OF EXPERIMENTS  .....................

fprintf(2,'\n \n \n \t * <strong>Stage 2.</strong> \n ') 
fprintf(2,'\n \n \t -> Average lambda: %1.3e \n \n',...
    mean(lambdaV(kS,:)));


% 2. Making experiments

AE2V=[]; betaV=[];

for sigma2=sigma2V
    [AEinf,AE2,beta,lambdaV,lambdaLV,XYZW,XYZWR]=demo_sphpoly(kS,a2,sigma2,...
        vertices,XYZW,XYZWR);
    AE2V=[AE2V AE2]; betaV=[betaV beta];
end

% 3. Making tables
AE2V2=AE2V; betaV2=betaV; BETAH2=betaV(4,:);
HypType=categorical({'tikhonov'; 'filtered'; 'lasso'; 'hybrid'; 'hard'; ...
    'hyperint.'; 'hyb.spars.'});
tablemat=[AE2V2; BETAH2];
T = table(HypType,tablemat); disp(T)




% ....................... PRODUCE LATEX TABLE  ............................

fprintf(2,'\n \n \t -> LaTeX table \n \n');

fileID=fopen('results_latex_sphpoly_stage1.txt','w');

strC={'Tikhonov'; 'Filtered'; 'Lasso'; 'Hybrid'; 'Hard'; 'Hyperint.'; ...
    '$\|{\mathbf{\beta}}\|_{0}$'};
for k=1:7
    strL=strC{k};

    strNUM='';

    for s=1:size(AE2V1,2)

        if k< 7
            strNUML=['$',num2str(AE2V1(k,s),'%.4f'),'$ &'];
        else
            strNUML=[ '$',num2str(BETAH1(s),'%.1f'),'$ &'];
        end

        strNUM=[strNUM strNUML];

    end


    for s=1:size(AE2V2,2)

        if k< 7
            strNUML=['$',num2str(AE2V2(k,s),'%.4f'),'$ &'];
        else
            strNUML=[ '$',num2str(BETAH2(s),'%.1f'),'$ &'];
        end

        strNUM=[strNUM strNUML];
        
    end

    if k ==7
        fprintf('\n \t'); disp('\hline');
        fprintf(fileID,'\n \t \\hline');
    end

    strNUM=[extractBefore(strNUM,length(strNUM)),'\\'];

    strdisp=['{\em{',strL,'}} &',strNUM];
    fprintf('\n \t '); disp(strdisp);

    strdispfile=replace(strdisp,'\','\\');
    fprintf(fileID,strcat('\n \t',' ',strdispfile));
end

fclose(fileID);








% ....................... THIRD STAGE OF EXPERIMENTS  .....................

fprintf(2,'\n \n \n \t * <strong>Stage 3.</strong> \n ') 

AE2P=[]; betaP=[]; JzHIST=[]; HzHIST=[];

% Making experiments.
for k=kP
    % fprintf('\n \t k: %3.0f',k)
    [AEinf,AE2,beta,lambdaV,lambdaLV,XYZW,XYZWR,JzL,HzL,Wg_norm2]=demo_sphpoly(k,...
        a3,sigma3,vertices,XYZW,XYZWR);
    AE2P=[AE2P AE2]; betaP=[betaP beta];
    JzHIST=[JzHIST JzL]; HzHIST=[HzHIST HzL];
end



% .................... PLOT FIGURE SPARSITY vs L2 ERROR  ..................

fprintf(2,'\n \n \t -> Plotting sparsity/L2 errors figure. \n') 

linewidth=1.7;
markersize=2;
fontsize=8;
legendsize=12;

figure(1)
subplot(1,2,1)


plot(betaP(3,:),JzHIST(3,:),'*','linewidth',linewidth,...
    'markersize',markersize,'color','r'), 
box on, set(gca,'fontsize',fontsize),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on

plot(betaP(3,:),HzHIST(3,:),'+','linewidth',linewidth,...
    'markersize',markersize,'color','r'), 
box on, set(gca,'fontsize',fontsize),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on

plot(betaP(4,:),JzHIST(4,:),'o','linewidth',linewidth,...
    'markersize',markersize,'color','r'), 
box on, set(gca,'fontsize',fontsize),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on

plot(betaP(4,:),HzHIST(4,:),'s','linewidth',linewidth,...
    'markersize',markersize,'color','r'), 
box on, set(gca,'fontsize',fontsize),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on


plot(betaP(5,:),JzHIST(5,:),'d','linewidth',linewidth,...
    'markersize',markersize,'color','r'), 
box on, set(gca,'fontsize',fontsize),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on

plot(betaP(5,:),HzHIST(5,:),'^','linewidth',linewidth,...
    'markersize',markersize,'color','r'), 
box on, set(gca,'fontsize',fontsize),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'), axis square,
hold on

yscale_symlog

legend({'Lasso (J)','Lasso (H)','Hybrid (J)','Hybrid (H)',...
    'Hard thresholding (J)','Hard thresholding (H)'},'interpreter','latex','fontsize',2*fontsize);

xlabel({'Sparsity $(a)$'},'interpreter','latex','fontsize',fontsize);
ylabel({'Values'},'interpreter','latex','fontsize',fontsize);
grid on;
%set(gca,'position',[0.04 0.05 0.45 0.9])

subplot(1,2,2)


semilogy(betaP(3,:),AE2P(3,:),'r*','linewidth',linewidth,'markersize',markersize),
box on, set(gca,'fontsize',legendsize),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on
semilogy(betaP(4,:),AE2P(4,:),'ko','linewidth',linewidth,'markersize',markersize),
box on, set(gca,'fontsize',legendsize),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on
semilogy(betaP(5,:),AE2P(5,:),'bd','linewidth',linewidth,'markersize',markersize),
box on, set(gca,'fontsize',legendsize),
set(gca, 'XMinorGrid', 'on'), set(gca, 'YMinorGrid', 'on'),axis square,
hold on

legend({'Lasso', 'Hybrid', 'Hard thresholding'},'interpreter','latex','fontsize',legendsize);

xlabel({'Sparsity $(b)$'},'interpreter','latex','fontsize',legendsize);
ylabel({'$L_2$ Errors'},'interpreter','latex','fontsize',legendsize);
grid on;
%set(gca,'position',[0.53 0.05 0.45 0.9])


% plot domain
figure(2)
plot_s2('spherical-polygon',vertices,XYZW(:,1:3));




function [vertices,domain_str]=define_domain(example)

%--------------------------------------------------------------------------
% Object:
% This routine, defines the domain to analyse.
%--------------------------------------------------------------------------
% Input:
% example: determines the spherical triangle domain to be analysed. From 0
%   to 7, going from large domains to tiny ones (the higher "example", the
%   smaller the domain.
%--------------------------------------------------------------------------
% Output:
% vertices: it is a matrix whose rows are the vertices of the spherical
%           triangles.
% domain_str: string that stores the geometry of the region.
%--------------------------------------------------------------------------


switch example
    
    case 0
        % Define spherical polygon.
        factor=0.5;
        t=linspace(0,2*pi,10); t=(t(1:end-1))';
        XV=factor*cos(t); YV=factor*sin(t); ZV=sqrt(1-XV.^2-YV.^2);
        % Note: spherical polygon (first vertices not equal to last).
        vertices=[XV YV ZV];
        
        domain_str='Polygonal cap at North-Pole';
        
    case 1
        
        spec_settings=32;
        th=linspace(0,2*pi,spec_settings+1);
        %th=(th(1:end-1))';
        polygon_sides=[cos(th').*(1-cos(th')) sin(th').*(1-cos(th'))];
        polygon_sides=polygon_sides(1:end-1,:);
        XV=polygon_sides(:,1); XV=XV/2.1;
        YV=polygon_sides(:,2); YV=YV/2.1;
        ZV=sqrt(1-XV.^2-YV.^2);
        vertices=[XV YV ZV];
        
        domain_str='Polygonal cardioid at North-Pole';
        
    case 2
        
        % Australia island vertices in degrees.
        % Column 1: Longitude. Column 2: Latitude.
        vertices_degs=100*[1.462300280000000  -0.386970830000000
            1.451162780000000  -0.381483330000000
            1.396121110000000  -0.361567220000000
            1.385678610000000  -0.348266670000000
            1.374529440000000  -0.349083330000000
            1.359337220000000  -0.345341940000000
            1.340596110000000  -0.329141390000000
            1.235266670000000  -0.339379720000000
            1.150004170000000  -0.335283610000000
            1.131528610000000  -0.261491940000000
            1.142312220000000  -0.263158890000000
            1.168041670000000  -0.205237780000000
            1.221729170000000  -0.172633330000000
            1.239712780000000  -0.168258330000000
            1.243913060000000  -0.163392220000000
            1.252495830000000  -0.155816670000000
            1.259183610000000  -0.146770830000000
            1.268749720000000  -0.137471390000000
            1.283721390000000  -0.154966940000000
            1.292900000000000  -0.148620830000000
            1.303179720000000  -0.133733330000000
            1.308121390000000  -0.124083330000000
            1.317678890000000  -0.113258330000000
            1.347483890000000  -0.119512500000000
            1.360166940000000  -0.124987780000000
            1.359095560000000  -0.132850000000000
            1.395983610000000  -0.175387780000000
            1.415862220000000  -0.125583610000000
            1.437729170000000  -0.143991940000000
            1.462604440000000  -0.188633890000000
            1.500416670000000  -0.221254170000000
            1.531929440000000  -0.259316940000000
            1.525429440000000  -0.324442220000000
            1.499796110000000  -0.375050560000000
            1.462300280000000  -0.386970830000000];
        
        % Australia island vertices in radians.
        longitudes=deg2rad(vertices_degs(:,1));
        latitudes=deg2rad(vertices_degs(:,2));
        
        % Australia island vertices in cartesian coordinates.
        [XX,YY,ZZ] = sph2cart(longitudes,latitudes,1);
        vertices=[XX YY ZZ];
        
        domain_str='Australia as island (33 vertices, via data)';
       
      case 3
          
                  
        % Australia island (no Tasmania), vertices in degrees.
        % Column 1: Longitude. Column 2: Latitude.
        % Planar domain in polyshape form.
        australia_pshape=coastline_australia(0);
        vertices_degs=australia_pshape.Vertices;
        
        % Australia & Tasmania vertices in radians.
        longitudes=deg2rad(vertices_degs(:,1));
        latitudes=deg2rad(vertices_degs(:,2));
        
        % Australia & Tasmania vertices in cartesian coordinates.
        [XX,YY,ZZ] = sph2cart(longitudes,latitudes,1);
        vertices=[XX YY ZZ];
        
        domain_str='Australia as island (170 vertices, via polyshape)';
        
        
        
end



