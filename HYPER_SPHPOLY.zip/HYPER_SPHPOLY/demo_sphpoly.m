
function  [AEinfMV,AE2MV,beta0MV,lambdaV,lambdaLV,XYZW,XYZWR,JzMV,HzMV,Wg_norm2]=...
    demo_sphpoly(lambda_index,a,sigma,vertices,XYZW,XYZWR,LV,do_compression)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Numerical experiment in "Hybrid hyperinterpolation over general regions".
% Region: spherical polygon.
%--------------------------------------------------------------------------
% Usage:
% >> demo_sphere
%--------------------------------------------------------------------------
% Note:
% The routine uses 'binornd' that requires Statistics and Machine Learning
% Toolbox.
%--------------------------------------------------------------------------
% Dates:
% Written on October 1, 2023: A. Sommariva.
% Modified on October 22, 2023: A. Sommariva.
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023-
%
% Authors:
% Alvise Sommariva
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------


% Defining lambda parameter (knowning hyp. coeffs, it is the k-th in
% descending absolute value!)
if nargin < 1, lambda_index=1; end

if nargin < 8, do_compression=0; end

%--------------------------------------------------------------------------
% Degrees of precision in numerical experiments: can be a vector.
%--------------------------------------------------------------------------
if nargin < 7
    LV=5;     % Hyperinterpolant maximum degree.
end
NV=2*LV;   % Degree of the rule used in hyperinterpolation.
NR=15;     % Degree of precision of the reference rule (estimate L2 error).

%--------------------------------------------------------------------------
% Noise and choice of lasso, hybrid, hard threshold parameter.
%--------------------------------------------------------------------------

noise=1;

if noise
    if nargin <2,a=0.2;end     % defining impulse noise (in experiment 2)
    if nargin <3,sigma=0.2;end % defining gaussian noise (in experiment 2)
else
    a=0; sigma=0; % no noise.
end

% * Function to approximate:
% 1. degree L poly., 2. degree floor(L/2)-1 poly. 3. test functions
% (see line 228 approx).
funct_example=3;

% No table or stats.
display_stats=0;

%--------------------------------------------------------------------------
% Special settings.
%--------------------------------------------------------------------------

% Plot domain and nodes: do_plot=1 (yes), do_plot=0 (no).
do_plot=0;

% Number of tests for reconstructing functions of a type on this domain.
ntests=10;




% ........................ Main code below ................................



% ........ Numerical approximation, varying the degree in "N" ............

AEinfMV=[]; AE2MV=[]; beta0MV=[]; % vectors used for statistics
JzMV=[]; HzMV=[];

for k=1:length(NV)

    N=NV(k); % Quadrature rule ade.
    L=LV(k); % Hyperinterpolant degree.

    % Define quadrature rule for hyperinterpolation at degree N.
    if nargin < 4, XYZW=cub_sphpgon(N,vertices); end
    if isempty(XYZW), XYZW=cub_sphpgon(N,vertices); end

do_compression

    if do_compression
        [XYZC,WC] = dCATCHsph(N,XYZW(:,1:3),XYZW(:,1:4));
        XYZWC=[XYZC WC];
        XYZW=XYZWC;
    end


    X=XYZW(:,1); Y=XYZW(:,2); Z=XYZW(:,3); W=XYZW(:,4);

    % Define quadrature rule for L2 error at degree NR.

    if nargin < 6, XYZWR=cub_sphpgon(NR,vertices); end

    if isempty(XYZWR)
        XYZWR=cub_sphpgon(NR,vertices);
    end

    XR=XYZWR(:,1); YR=XYZWR(:,2); ZR=XYZWR(:,3);  WR=XYZWR(:,4);

    % Vandermonde matrix at nodes and polynomial degrees.
    % [V,degs]=vandermonde_sphharm(L,[X Y Z]);

    [~,jvec,Q,R,dbox,degs]=dORTHVANDsph(L,[X Y Z],W);

    % Testing hyperinterpolation errors for each "f" at "deg".

    poly_coeffs=[];
    lambdaV=[];
    lambdaLV=[];

    for j=1:ntests

        % define function (see attached file at the bottom)
        g=choose_function(funct_example,L);

        % ... evaluate function to approximate ...
        gXYZ=feval(g,X,Y,Z);

        % ... Add noise (if present) ...

        % add impulse noise
        pert_impulse=0;
        if a > 0
            pert_impulse=a*(1-2*rand(length(gXYZ),1))*binornd(1,0.5);
            while norm(pert_impulse) == 0
                pert_impulse=a*(1-2*rand(length(gXYZ),1))*binornd(1,0.5);
            end
        end

        % add gaussian noise
        pert_gauss=0;
        if sigma > 0
            var=sigma^2;
            pert_gauss=sqrt(var)*randn(size(gXYZ));
            while norm(pert_gauss) == 0
                pert_gauss=sqrt(var)*randn(size(gXYZ));
            end
        end

        % add gaussian + impulse noise
        pert=pert_impulse+pert_gauss;

        % perturbed values
        gXYZ_pert=gXYZ+pert;

        % ... determine polynomial hyperinterpolant ...
        coeff0=Q'*(sqrt(W).*gXYZ);

        lambdas=sort(abs(coeff0),'descend');

        lambdaL=lambdas(lambda_index);

        for ktest=1:6
            switch ktest
                case 1
                    hypermode='tikhonov';
                    parms.lambda=lambdaL;
                    parms.mu=[];
                    parms.b=ones(size(coeff0));
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 2
                    hypermode='filtered';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 3
                    hypermode='lasso';
                    parms.lambda=lambdaL;
                    parms.mu=ones(size(coeff));
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 4
                    hypermode='hybrid';
                    parms.lambda=lambdaL;
                    parms.mu=ones(size(coeff0));
                    parms.b=ones(size(coeff0));
                    parms.w=W;
                    parms.pert=pert;
                    parms.hybrid=0; % establishes it is a pre-choosen parameter.
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 5
                    hypermode='hard';
                    parms.lambda=lambdaL;
                    parms.mu=[];
                    parms.b=[];
                    coeff=hyperfilter(hypermode,coeff0,degs,parms);
                case 6
                    hypermode='hyperinterpolation';
                    parms.lambda=[];
                    parms.mu=[];
                    parms.b=[];
                    coeff=coeff0;
            end

            gXYZR=feval(g,XR,YR,ZR);
            pXYZR = dPOLYVALsph(L,coeff',[XR YR ZR],R,jvec,dbox);

            % errors
            AEinfV(ktest,j)=norm(gXYZR-pXYZR,inf); % absolute error (inf norm)
            AE2V(ktest,j)=sqrt(WR'*((gXYZR-pXYZR).^2)); % absolute error (2 norm)
            beta0V(ktest,j)=sum(abs(coeff) > 0);

            % evaluate J(coeff) and H(coeff), that are error relevant
            % parameters, as observed in Thm 5.1.

            JzV(ktest,j)=NaN;
            HzV(ktest,j)=NaN;

        end


        lambdaLV=[lambdaLV lambdaL];
        lambdaV=[lambdaV lambdas];

    end


    % averages of the errors (vectors 5 x 1)
    AEinfM=mean(AEinfV,2);
    AE2M=mean(AE2V,2);
    beta0M=mean(beta0V,2);
    JzM=mean(JzV,2);
    HzM=mean(HzV,2);

    if display_stats
        fprintf('\n       ........ table at degree: %2.0f ........ \n \n ',...
            N);
        HypType=categorical({'tikhonov'; 'filtered'; 'lasso'; 'hybrid'; ...
            'hard'; 'hyperint.'});
        T = table(HypType,AEinfM,AE2M,beta0M,JzM,HzM); disp(T)
    end

    AEinfMV=[AEinfMV AEinfM]; AE2MV=[AE2MV AE2M]; beta0MV=[beta0MV beta0M];
    JzMV=[JzMV JzM]; HzMV=[HzMV HzM];

end

Wg_norm2=(norm(sqrt(W).*gXYZ,2))^2;







function g=choose_function(funct_example,L)

switch funct_example

    case 1 % test exactness hyperinterpolation
        nexp=L;
        c0=rand(1); c1=rand(1); c2=rand(1); c3=rand(1);
        g=@(x,y,z) (c0+c1*x+c2*y+c3*z).^nexp;

    case 2 % test exactness filt. hyperinterpolation
        nexp=max(floor(L/2)-1,0);
        c0=rand(1); c1=rand(1); c2=rand(1); c3=rand(1);
        g=@(x,y,z) (c0+c1*x+c2*y+c3*z).^nexp;

    case 3 % function of that type

        funct_example_sub=3;

        switch funct_example_sub
            case 0
                g=@(x,y,z) exp(-1./(x.^2+y.^2+z.^2));
                % fstring='exp(-1./(x.^2+y.^2+z.^2))';
            case 1
                g=@(x,y,z) (1-x.^2-y.^2-z.^2).*exp(x.*cos(y));
                % fstring='(1-x.^2-y.^2-z.^2).*exp(x.*cos(y))';
            case 2
                g=@(x,y,z) exp((x.^6).*cos(y+2*z));
                % fstring='exp((x.^6).*cos(y+2*z))';
            case 3 % Test function used in the accompanying paper.
                delta2=9*gamma(5/2)/(2*gamma(3));
                phi_tilde=@(r) (((1-r).*(1-r > 0)).^6).*(35*r.^2+18*r+3);
                r1=@(x,y,z) ((x-1).^2+y.^2+z.^2)/delta2; %z1=[1 0 0]
                r2=@(x,y,z) ((x+1).^2+y.^2+z.^2)/delta2; %z2=[-1 0 0]
                r3=@(x,y,z) (x.^2+(y-1).^2+z.^2)/delta2; %z3=[0 1 0]
                r4=@(x,y,z) (x.^2+(y+1).^2+z.^2)/delta2; %z4=[0 -1 0]
                r5=@(x,y,z) (x.^2+y.^2+(z-1).^2)/delta2; %z5=[0 0 1]
                r6=@(x,y,z) (x.^2+y.^2+(z+1).^2)/delta2; %z6=[0 0 -1]
                g=@(x,y,z) (1/3)*(phi_tilde(r1(x,y,z))+...
                    phi_tilde(r2(x,y,z))+phi_tilde(r3(x,y,z))+...
                    phi_tilde(r4(x,y,z))+phi_tilde(r5(x,y,z))+...
                    phi_tilde(r6(x,y,z)));
        end


end




function Jz=evaluate_J(z,alpha)

%--------------------------------------------------------------------------
% Object:
% Evaluate function J(z)=sum( (z(l))^2-2*z(l)*alpha(l) )
%--------------------------------------------------------------------------
% Input:
% z    : vector of dimension d x 1
% alpha: vector of dimension d x 1
%--------------------------------------------------------------------------
% Output:
% Jz: value of J(z)=sum( (z(l))^2-2*z(l)*alpha(l) )
%--------------------------------------------------------------------------
% Reference:
% Quantity relevant in Thm. 5.1 of the paper
% "Hybrid hyperinterpolation over general regions"
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------

% Jz=sum(z.^2-2*z.*alpha);
Jz=z'*z -2*z'*alpha;




function Hz=evaluate_H(z,w,err,V)

%--------------------------------------------------------------------------
% Object:
% Evaluate function H(z)=2*sum_l( z(l) * sum_j( w(j)*err(j)*V(l,j) ) )
%--------------------------------------------------------------------------
% Input:
% z    : vector of dimension d x 1
% w    : vector of dimension N x 1
% err  : vector of dimension N x 1
% V    : matrix of dimension d x N
%--------------------------------------------------------------------------
% Output:
% Hz: value of H(z)=2*sum_l( z(l) * sum_j( w(j)*err(j)*V(l,j) ) )
%--------------------------------------------------------------------------
% Reference:
% Quantity relevant in Thm. 5.1 of the paper
% "Hybrid hyperinterpolation over general regions"
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------

inner_term=V'*(w.*err);
outer_term=z'*inner_term;
Hz=2*outer_term;






